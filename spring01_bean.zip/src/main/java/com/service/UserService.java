package com.service;

// 빈(클래스)
public class UserService {

	public UserService() {
		System.out.println("UserService 생성자");
	}
	
	
}
