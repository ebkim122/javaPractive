package com.dto;

import java.util.*;

public class Person {
	
	String username;
	int userage;
	
	Map<String, Cat> catMap;	//검색속도가 매우 빠르다.

	//전화번호 ==> List, Set, Map 가능
	//Properties : key/value 쌍으로 저장시 value 값이 문자열로 한정된 경우 사용 가능
	Properties phones;
	
	public Properties getPhones() {
		return phones;
	}

	public void setPhones(Properties phones) {
		this.phones = phones;
	}

	@Override
	public String toString() {
		return "Person [username=" + username + ", userage=" + userage + ", catMap=" + catMap + "]";
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getUserage() {
		return userage;
	}

	public void setUserage(int userage) {
		this.userage = userage;
	}

	public Map<String, Cat> getCatMap() {
		return catMap;
	}

	public void setCatMap(Map<String, Cat> catMap) {
		this.catMap = catMap;
	}
	
}
