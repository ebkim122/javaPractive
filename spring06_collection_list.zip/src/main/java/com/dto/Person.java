package com.dto;

import java.util.List;

public class Person {
	
	String username;
	int userage;
	
	List<Cat> catList;

	@Override
	public String toString() {
		return "Person [username=" + username + ", userage=" + userage + ", catList=" + catList + "]";
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getUserage() {
		return userage;
	}

	public void setUserage(int userage) {
		this.userage = userage;
	}


	public List<Cat> getCatList() {
		return catList;
	}

	public void setCatList(List<Cat> catList) {
		this.catList = catList;
	}
	
}
