package com.service;

import java.util.List;

import com.dao.UserDAO;

// 빈(클래스)
// UserDAO 빈 접근
public class UserService {
	
	UserDAO dao;
	
	public UserService() {
		System.out.println("UserService 생성자");
	}
	
	// Constructor-based injection
	// 생성자를 통해서 변수에 외부에서 만들어진 데이터 주입 
	public UserService(UserDAO dao) {
		System.out.println("UserService(UserDAO dao) 생성자");
		this.dao = dao;
	}
	
	public List<String> getList() {
		return dao.getList();
	}
	
}
