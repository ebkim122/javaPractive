package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dao.UserDAO;

// 빈(클래스)
// UserDAO 빈 접근
public class UserService {

	// @Autowired : 자동으로 주입, 활성화 필요 : 변수(프라퍼티);가장 일반적, set메서드, 생성자
	// Autowired를 쓰면 'xml에 등록된 bean' 중 이름이 같은걸 찾는다.
	// 변수에 하면 getter, setter 메서드 불필요. 코드가 간결해짐
	@Autowired
	UserDAO dao;
	
	public UserService() {
		System.out.println("UserService 생성자");
	}

//	public UserDAO getDao() {
//		return dao;
//	}
	
	// setter-based injection
	// @Autowired : 자동으로 주입, 활성화 필요
//	@Autowired
//	public void setDao(UserDAO dao) {
//		System.out.println("setDao injection");
//		this.dao = dao;
//	}

	public List<String> getList() {
		return dao.getList();
	}
	
}
