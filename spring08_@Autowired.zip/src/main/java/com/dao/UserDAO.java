package com.dao;

import java.util.Arrays;
import java.util.List;

// UserService에서 사용되는 빈
public class UserDAO {

	public UserDAO() {
		System.out.println("UserDAO 생성자");
	}
	
	// 오라클 데이터베이스 연동해서 데이터 얻기 (연동 했다는 가정)
	public List<String> getList() {
		List<String> list = Arrays.asList("김은별", "김한별", "김지택");
		return list;		
	}
	
}
