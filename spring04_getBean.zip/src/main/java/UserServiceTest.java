import org.springframework.context.support.GenericXmlApplicationContext;

import com.service.UserService;

// 핸들링 클래스(메인 메소드가 존재하는 클래스)
public class UserServiceTest {

	public static void main(String[] args) {
		
		// 1. 이전 방식 ==> 직접 new 이용해서 객체 생성
//		UserService service = new UserService();
		
		// 2. 스프링 ==> 빈 등록( resources 안에 xml 파일 )
		// user.xml 인식시키기. 해당 파일에 등록되어 있는 빈을 메모리에 올린다.
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("user.xml");
		
		// 생성된 빈 얻기
		// xml 파일에 입력된 빈의 id로 클래스를 불러온다. getBean 
		UserService service = ctx.getBean("service", UserService.class);
		System.out.println(service.getService());
	}

}
