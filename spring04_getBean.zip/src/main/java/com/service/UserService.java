package com.service;

// 빈(클래스)
public class UserService {

	public UserService() {
		System.out.println("UserService 생성자");
	}
	
	public String getService() {
		return "UserService 입니다.";
	}
}
