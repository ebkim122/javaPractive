package com.service;

// 빈(클래스)
public class UserService {

	public UserService() {
		System.out.println("UserService 생성자");
	}
	
	public void aaa() {
		System.out.println("Init Method:aaa()");
	}
	
	public void bbb() {
		System.out.println("Destroy Method:bbb()");
	}
}
