import java.util.*;

import org.springframework.context.support.GenericXmlApplicationContext;

import com.dto.Cat;
import com.dto.Person;

public class PersonTest {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("person.xml");
		
		// Person 얻어서 값을 출력
		/*	출력 포맷 :
		 *  이름:홍길동 나이:20 고양이이름:나비 고양이나이:2
		 */
		
		Person p = ctx.getBean("p01", Person.class);
		String username = p.getUsername();
		int userage = p.getUserage();
		Map<String, Cat> catMap = p.getCatMap();
		// key값을 먼저 얻는다.
		Set<String> keys = catMap.keySet();
		
		for (String k : keys) {
			System.out.println(k + " = " + catMap.get(k));
		}
//		System.out.println(username+"\t"+userage+"\t"+catMap);

	}

}
