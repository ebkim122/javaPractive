package com.dto;

import java.util.*;

public class Person {
	
	String username;
	int userage;
	
	Map<String, Cat> catMap;	//검색속도가 매우 빠르다.

	@Override
	public String toString() {
		return "Person [username=" + username + ", userage=" + userage + ", catMap=" + catMap + "]";
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getUserage() {
		return userage;
	}

	public void setUserage(int userage) {
		this.userage = userage;
	}

	public Map<String, Cat> getCatMap() {
		return catMap;
	}

	public void setCatMap(Map<String, Cat> catMap) {
		this.catMap = catMap;
	}
	
}
