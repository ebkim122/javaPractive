package com.service;

import java.util.List;

import com.dao.UserDAO;

// 빈(클래스)
// UserDAO 빈 접근
public class UserService {
	
	UserDAO dao;
	
	public UserService() {
		System.out.println("UserService 생성자");
	}

	public UserDAO getDao() {
		return dao;
	}
	
	// setter-based injection
	public void setDao(UserDAO dao) {
		System.out.println("setDao injection");
		this.dao = dao;
	}

	public List<String> getList() {
		return dao.getList();
	}
	
}
