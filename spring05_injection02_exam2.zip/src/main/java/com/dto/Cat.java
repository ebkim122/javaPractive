package com.dto;

public class Cat {
	// has-a 관계(use-a) ==> injection (생성자/setter 메서드)
	String name;
	int age;

	public Cat() {
	}
	
	//injection
	public Cat(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	
	
	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	@Override
	public String toString() {
		return "고양이이름 : " + name + ", 고양이나이 : " + age;
	}
	
	
	
}
