package com.dto;

public class Person {
	
	String username;
	int userage;
	
	// has-a 관계(use-a) ==> injection (생성자/setter 메서드)
	Cat cat;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getUserage() {
		return userage;
	}

	public void setUserage(int userage) {
		this.userage = userage;
	}

	public Cat getCat() {
		return cat;
	}

	public void setCat(Cat cat) {
		this.cat = cat;
	}

	@Override
	public String toString() {
		return "이름 : " + username + ", 나이 : " + userage + ", " + cat;
	}
	
	
	
}
