import java.util.List;

import org.springframework.context.support.GenericXmlApplicationContext;

import com.dto.User;
import com.service.UserService;

// 핸들링 클래스(메인 메소드가 존재하는 클래스)
public class UserTest {

	public static void main(String[] args) {
		
		// user.xml 인식시키기
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("com/config/user.xml");
		
		// UserService 얻기
		UserService service = ctx.getBean("userService", UserService.class);
		List<User> list = service.getUserList();
		for (User user : list) {
			System.out.println(user);
		}
	}

}
