package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dao.UserDAO;
import com.dto.User;

// UserDAO 사용한다.
public class UserService {
	
	@Autowired
	UserDAO dao;
	
	public List<User> getUserList() {
		return dao.getUserList();
	}
	
}
