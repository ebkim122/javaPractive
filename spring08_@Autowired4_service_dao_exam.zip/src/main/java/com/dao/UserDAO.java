package com.dao;

import java.util.ArrayList;
import java.util.List;

import com.dto.User;

// DAO : Data Access Object 패턴
public class UserDAO {
	
	/*
	 * User 테이블
	 * 
	 * 이름 나이 주소 성별
	 * 홍길동 20 경기 남		==> 행 저장(User.java)
	 * 이순신 33 전라 남
	 * 유관순 17 경기 여
	 */
	
	public List<User> getUserList() {
		List<User> list = new ArrayList<User>();
		list.add(new User("홍길동", 20, "경기", "남"));
		list.add(new User("이순신", 33, "전라", "남"));
		list.add(new User("유관순", 17, "경기", "여"));
		return list;
	}
	
}
