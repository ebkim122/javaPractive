import org.springframework.context.support.GenericXmlApplicationContext;

import com.service.UserService;

// 핸들링 클래스(메인 메소드가 존재하는 클래스)
public class UserServiceTest {

	public static void main(String[] args) {
		
		// 1. 이전 방식 ==> 직접 new 이용해서 객체 생성
//		UserService service = new UserService();
		
		// 2. 스프링 ==> 빈 등록( resources 안에 xml 파일 )
		// user.xml 인식시키기
		// resource 파일의 package 인식은 "/"로 한다.
		// xml 파일 여러개 등록 가능함. ","로 구분
//		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("com/config/user.xml", "com/config/owner.xml");
		// "*"로 해당 패키지 안에 있는 xml 파일 모두를 등록 가능
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("com/config/*.xml");
		
	}

}
