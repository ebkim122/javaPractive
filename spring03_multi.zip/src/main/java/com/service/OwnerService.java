package com.service;

// 빈(클래스)
public class OwnerService {

	public OwnerService() {
		System.out.println("OwnerService 생성자");
	}
	
	
}
