package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Required;

import com.dao.UserDAO;

// 빈(클래스)
// UserDAO 빈 접근
public class UserService {
	
	UserDAO dao;
	
	public UserService() {
		System.out.println("UserService 생성자");
	}

	public UserDAO getDao() {
		return dao;
	}
	
	// setter-based injection
	// @Required : 반드시 객체에 데이터를 주입시키도록 명시하여 강제화. 반드시 user.xml에서 활성화 지정한다. <context:annotation-config />
	@Required
	public void setDao(UserDAO dao) {
		System.out.println("setDao injection");
		this.dao = dao;
	}

	public List<String> getList() {
		return dao.getList();
	}
	
}
