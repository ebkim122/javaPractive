package com.dto;

import java.util.*;

public class Person {
	
	String username;
	int userage;
	
	Set<Cat> catSet;

	@Override
	public String toString() {
		return "Person [username=" + username + ", userage=" + userage + ", catSet=" + catSet + "]";
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getUserage() {
		return userage;
	}

	public void setUserage(int userage) {
		this.userage = userage;
	}

	public Set<Cat> getCatSet() {
		return catSet;
	}

	public void setCatSet(Set<Cat> catSet) {
		this.catSet = catSet;
	}
	
	
}
