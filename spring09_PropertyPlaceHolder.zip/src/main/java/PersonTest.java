import org.springframework.context.support.GenericXmlApplicationContext;

import com.dto.Person;

public class PersonTest {

	public static void main(String[] args) {
		
		// xml 지정
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("person.xml");
		
		// 빈 얻기
		Person p = ctx.getBean("p02", Person.class);
		System.out.println(p);

	}

}
